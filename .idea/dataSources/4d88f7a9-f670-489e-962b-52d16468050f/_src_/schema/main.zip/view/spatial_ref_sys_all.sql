CREATE VIEW spatial_ref_sys_all AS
SELECT a.srid AS srid, a.auth_name AS auth_name, a.auth_srid AS auth_srid, a.ref_sys_name AS ref_sys_name,
b.is_geographic AS is_geographic, b.has_flipped_axes AS has_flipped_axes, b.spheroid AS spheroid, b.prime_meridian AS prime_meridian, b.datum AS datum, b.projection AS projection, b.unit AS unit,
b.axis_1_name AS axis_1_name, b.axis_1_orientation AS axis_1_orientation,
b.axis_2_name AS axis_2_name, b.axis_2_orientation AS axis_2_orientation,
a.proj4text AS proj4text, a.srtext AS srtext
FROM spatial_ref_sys AS a
LEFT JOIN spatial_ref_sys_aux AS b ON (a.srid = b.srid);
