CREATE VIEW vector_layers_field_infos AS
SELECT 'SpatialTable' AS layer_type, f_table_name AS table_name, f_geometry_column AS geometry_column, ordinal AS ordinal, column_name AS column_name, null_values AS null_values, integer_values AS integer_values, double_values AS double_values, text_values AS text_values, blob_values AS blob_values, max_size AS max_size, integer_min AS integer_min, integer_max AS integer_max, double_min AS double_min, double_max double_max
FROM geometry_columns_field_infos
UNION
SELECT 'SpatialView' AS layer_type, view_name AS table_name, view_geometry AS geometry_column, ordinal AS ordinal, column_name AS column_name, null_values AS null_values, integer_values AS integer_values, double_values AS double_values, text_values AS text_values, blob_values AS blob_values, max_size AS max_size, integer_min AS integer_min, integer_max AS integer_max, double_min AS double_min, double_max double_max
FROM views_geometry_columns_field_infos
UNION
SELECT 'VirtualShape' AS layer_type, virt_name AS table_name, virt_geometry AS geometry_column, ordinal AS ordinal, column_name AS column_name, null_values AS null_values, integer_values AS integer_values, double_values AS double_values, text_values AS text_values, blob_values AS blob_values, max_size AS max_size, integer_min AS integer_min, integer_max AS integer_max, double_min AS double_min, double_max double_max
FROM virts_geometry_columns_field_infos;
