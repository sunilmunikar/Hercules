CREATE VIEW vector_layers_statistics AS
SELECT 'SpatialTable' AS layer_type, f_table_name AS table_name, f_geometry_column AS geometry_column, last_verified AS last_verified, row_count AS row_count, extent_min_x AS extent_min_x, extent_min_y AS extent_min_y, extent_max_x AS extent_max_x, extent_max_y AS extent_max_y
FROM geometry_columns_statistics
UNION
SELECT 'SpatialView' AS layer_type, view_name AS table_name, view_geometry AS geometry_column, last_verified AS last_verified, row_count AS row_count, extent_min_x AS extent_min_x, extent_min_y AS extent_min_y, extent_max_x AS extent_max_x, extent_max_y AS extent_max_y
FROM views_geometry_columns_statistics
UNION
SELECT 'VirtualShape' AS layer_type, virt_name AS table_name, virt_geometry AS geometry_column, last_verified AS last_verified, row_count AS row_count, extent_min_x AS extent_min_x, extent_min_y AS extent_min_y, extent_max_x AS extent_max_x, extent_max_y AS extent_max_y
FROM virts_geometry_columns_statistics;
