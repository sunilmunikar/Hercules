CREATE TRIGGER vtgcfi_virt_name_insert
BEFORE INSERT ON 'virts_geometry_columns_field_infos'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on virts_geometry_columns_field_infos violates constraint: virt_name value must not contain a single quote')
WHERE NEW.virt_name LIKE ('%''%');
SELECT RAISE(ABORT,'insert on virts_geometry_columns_field_infos violates constraint: virt_name value must not contain a double quote')
WHERE NEW.virt_name LIKE ('%"%');
SELECT RAISE(ABORT,'insert on virts_geometry_columns_field_infos violates constraint: 
virt_name value must be lower case')
WHERE NEW.virt_name <> lower(NEW.virt_name);
END