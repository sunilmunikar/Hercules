CREATE TRIGGER vtgc_virt_name_insert
BEFORE INSERT ON 'virts_geometry_columns'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'insert on virts_geometry_columns violates constraint: virt_name value must not contain a single quote')
WHERE NEW.virt_name LIKE ('%''%');
SELECT RAISE(ABORT,'insert on virts_geometry_columns violates constraint: virt_name value must not contain a double quote')
WHERE NEW.virt_name LIKE ('%"%');
SELECT RAISE(ABORT,'insert on virts_geometry_columns violates constraint: 
virt_name value must be lower case')
WHERE NEW.virt_name <> lower(NEW.virt_name);
END