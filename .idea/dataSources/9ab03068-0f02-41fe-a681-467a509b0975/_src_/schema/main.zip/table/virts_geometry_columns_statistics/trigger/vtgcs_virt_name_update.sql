CREATE TRIGGER vtgcs_virt_name_update
BEFORE UPDATE OF 'virt_name' ON 'virts_geometry_columns_statistics'
FOR EACH ROW BEGIN
SELECT RAISE(ABORT,'update on virts_geometry_columns_statistics violates constraint: virt_name value must not contain a single quote')
WHERE NEW.virt_name LIKE ('%''%');
SELECT RAISE(ABORT,'update on virts_geometry_columns_statistics violates constraint: virt_name value must not contain a double quote')
WHERE NEW.virt_name LIKE ('%"%');
SELECT RAISE(ABORT,'update on virts_geometry_columns_statistics violates constraint: virt_name value must be lower case')
WHERE NEW.virt_name <> lower(NEW.virt_name);
END